<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Helpdesk
 * @author    Webkul
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Helpdesk\Block\Adminhtml\Ticketsmanagement\Attribute\Edit\Tab;

class Options extends \Webkul\Helpdesk\Block\Adminhtml\Ticketsmanagement\Attribute\Edit\Tab\AbstractOptions
{
}
